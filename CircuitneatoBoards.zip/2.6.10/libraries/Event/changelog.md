# Changelog

## 1.2.1 (6/10/22)
* Fix a bunch of bugs impacting tinyAVR 0/1-series, including with long_soft_event
* Beginnings of support for EA, I think the path forward is clear.
