# IntelHex library version information 
version_info = (2, 3, 0)
version_str = '.'.join([str(i) for i in version_info])
