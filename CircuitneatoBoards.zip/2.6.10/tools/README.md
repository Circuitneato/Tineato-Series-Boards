# SerialUPDI
[Relocated to keep all information in one place](https://github.com/SpenceKonde/AVR-Guidance/blob/master/UPDI/jtag2updi.md)

## Instructions for [making manual installation work with Serial UPDI](https://github.com/SpenceKonde/megaTinyCore/blob/master/megaavr/tools/ManualPython.md)
It requires a manual download of a specific python package. It is not so much hard as just annoying, but generally need only be done once.
